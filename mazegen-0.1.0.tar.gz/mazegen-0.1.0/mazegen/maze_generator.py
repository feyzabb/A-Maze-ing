import random
from typing import List, Tuple, Dict
from collections import deque
from .maze import Cell
import sys


class MazeGenerator:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.grid = [
            [Cell(x, y) for x in range(width)]
            for y in range(height)
        ]
        self._pattern_cells: List[Tuple[int, int]] = (
            self._compute_42_pattern_cells()
        )

    def _compute_42_pattern_cells(self) -> List[Tuple[int, int]]:
        pattern_width = 8
        pattern_height = 5

        if self.width < pattern_width or self.height < pattern_height:
            print("Warning: Maze size is too small to fit the '42' pattern.",
                  file=sys.stderr)
            return []

        start_x = (self.width - pattern_width) // 2
        start_y = (self.height - pattern_height) // 2

        pattern_offsets = [
            (0, 0),         (2, 0),
            (0, 1),         (2, 1),
            (0, 2), (1, 2), (2, 2),
                            (2, 3),
                            (2, 4),

            (5, 0), (6, 0), (7, 0),
                            (7, 1),
            (5, 2), (6, 2), (7, 2),
            (5, 3),
            (5, 4), (6, 4), (7, 4)
        ]

        return [(start_x + dx, start_y + dy) for dx, dy in pattern_offsets]

    def is_pattern_cell(self, x: int, y: int) -> bool:
        return (x, y) in self._pattern_cells

    def mark_42_pattern_as_visited(self) -> None:
        if not self._pattern_cells:
            return

        for x, y in self._pattern_cells:
            self.grid[y][x].visited = True

    def _get_neighbors(
        self,
        cell: Cell
    ) -> List[Tuple[str, Cell]]:
        neighbors = []
        x, y = cell.x, cell.y

        if y > 0 and not self.grid[y - 1][x].visited:
            neighbors.append(("N", self.grid[y - 1][x]))

        if y < self.height - 1 and not self.grid[y + 1][x].visited:
            neighbors.append(("S", self.grid[y + 1][x]))

        if x < self.width - 1 and not self.grid[y][x + 1].visited:
            neighbors.append(("E", self.grid[y][x + 1]))

        if x > 0 and not self.grid[y][x - 1].visited:
            neighbors.append(("W", self.grid[y][x - 1]))

        return neighbors

    def generate_perfect_maze(self) -> None:
        start_cell = self.grid[0][0]
        start_cell.visited = True

        stack = [start_cell]

        while stack:
            current = stack[-1]
            valid_moves = self._get_neighbors(current)

            if valid_moves:
                direction, next_cell = random.choice(valid_moves)

                opposite_walls = {
                    "N": "S",
                    "S": "N",
                    "E": "W",
                    "W": "E",
                }

                current.walls[direction] = False
                next_cell.walls[opposite_walls[direction]] = False
                next_cell.visited = True
                stack.append(next_cell)
            else:
                stack.pop()

    def generate_pacman_maze(self) -> None:
        self._remove_dead_ends()
        self._add_loops(2)
        self._open_pacman_special_cells()

    def _is_safe_to_break(self, x: int, y: int, direction: str) -> bool:
        dx, dy = 0, 0
        if direction == "N":
            dy = -1
        elif direction == "S":
            dy = 1
        elif direction == "E":
            dx = 1
        elif direction == "W":
            dx = -1

        nx, ny = x + dx, y + dy

        if not (0 <= nx < self.width and 0 <= ny < self.height):
            return False

        pattern_cells = set(self._pattern_cells)

        if (nx, ny) in pattern_cells:
            return False

        self.grid[y][x].walls[direction] = False
        opposite = {"N": "S", "S": "N", "E": "W", "W": "E"}[direction]
        self.grid[ny][nx].walls[opposite] = False

        is_safe = True

        for cy in range(max(0, min(y, ny) - 2), min(max(y, ny) + 1,
                                                    self.height - 2)):
            for cx in range(max(0, min(x, nx) - 2), min(max(x, nx) + 1,
                                                        self.width - 2)):
                area_is_fully_open = True

                for i in range(3):
                    for j in range(3):
                        cell_y = cy + i
                        cell_x = cx + j

                        if j < 2 and self.grid[cell_y][cell_x].walls["E"]:
                            area_is_fully_open = False
                            break
                        if i < 2 and self.grid[cell_y][cell_x].walls["S"]:
                            area_is_fully_open = False
                            break
                    if not area_is_fully_open:
                        break
                if area_is_fully_open:
                    is_safe = False
                    break

            if not is_safe:
                break

        self.grid[y][x].walls[direction] = True
        self.grid[ny][nx].walls[opposite] = True

        return is_safe

    def _remove_dead_ends(self) -> None:
        opposite_walls = {
                    "N": "S",
                    "S": "N",
                    "E": "W",
                    "W": "E",
                }
        pattern_cells = set(self._pattern_cells)

        while True:
            changed = False

            for y in range(self.height):
                for x in range(self.width):
                    if (x, y) in pattern_cells:
                        continue

                    cell = self.grid[y][x]

                    closed_walls = [
                        direction
                        for direction, is_closed in cell.walls.items()
                        if is_closed
                    ]

                    if len(closed_walls) != 3:
                        continue

                    breakable_walls = []

                    if "N" in closed_walls and y > 0:
                        breakable_walls.append("N")
                    if "S" in closed_walls and y < self.height - 1:
                        breakable_walls.append("S")
                    if "E" in closed_walls and x < self.width - 1:
                        breakable_walls.append("E")
                    if "W" in closed_walls and x > 0:
                        breakable_walls.append("W")

                    safe_walls = [
                        wall
                        for wall in breakable_walls
                        if self._is_safe_to_break(x, y, wall)
                    ]

                    if not safe_walls:
                        continue

                    wall_to_break = random.choice(safe_walls)

                    cell.walls[wall_to_break] = False

                    if wall_to_break == "N":
                        neighbor = self.grid[y - 1][x]

                    elif wall_to_break == "S":
                        neighbor = self.grid[y + 1][x]

                    elif wall_to_break == "E":
                        neighbor = self.grid[y][x + 1]

                    else:
                        neighbor = self.grid[y][x - 1]

                    neighbor.walls[
                        opposite_walls[wall_to_break]
                        ] = False

                    changed = True

            if not changed:
                break

    def _add_loops(self, minimum_loops: int = 2) -> None:
        pattern_cells = set(self._pattern_cells)

        directions = [
            ("N", 0, -1, "S"),
            ("S", 0, 1, "N"),
            ("E", 1, 0, "W"),
            ("W", -1, 0, "E"),
        ]

        candidates = []

        for y in range(self.height):
            for x in range(self.width):
                if (x, y) in pattern_cells:
                    continue

                cell = self.grid[y][x]

                for direction, dx, dy, opposite in directions:
                    nx = x + dx
                    ny = y + dy

                    if not (0 <= nx < self.width and 0 <= ny < self.height):
                        continue

                    if (nx, ny) in pattern_cells:
                        continue

                    if not cell.walls[direction]:
                        continue

                    if self._is_safe_to_break(x, y, direction):
                        candidates.append(
                            (x, y, direction, nx, ny, opposite)
                        )

        random.shuffle(candidates)

        loops_added = 0

        for x, y, direction, nx, ny, opposite in candidates:
            if loops_added >= minimum_loops:
                break

            if not self.grid[y][x].walls[direction]:
                continue

            if not self._is_safe_to_break(x, y, direction):
                continue

            self.grid[y][x].walls[direction] = False
            self.grid[ny][nx].walls[opposite] = False

            loops_added += 1

    def _close_cell_completely(self, x: int, y: int) -> None:
        cell = self.grid[y][x]
        cell.walls["N"] = True
        cell.walls["S"] = True
        cell.walls["E"] = True
        cell.walls["W"] = True

        if y > 0:
            self.grid[y-1][x].walls["S"] = True
        if y < self.height - 1:
            self.grid[y+1][x].walls["N"] = True
        if x > 0:
            self.grid[y][x-1].walls["E"] = True
        if x < self.width - 1:
            self.grid[y][x+1].walls["W"] = True

    def add_42(self) -> None:
        if not self._pattern_cells:
            return

        for x, y in self._pattern_cells:
            self._close_cell_completely(x, y)

    def solve_maze(self, start: Tuple[int, int],
                   end: Tuple[int, int]) -> List[str]:
        start_x, start_y = start
        exit_x, exit_y = end

        start_cell = self.grid[start_y][start_x]

        queue = deque([start_cell])
        visited = set()
        visited.add((start_x, start_y))

        parent_map: Dict[Tuple[int, int], Tuple[Tuple[int, int], str]] = {}

        while queue:
            current_cell = queue.popleft()

            if current_cell.x == exit_x and current_cell.y == exit_y:
                break

            directions = [
                (0, -1, 'N', 'N'),
                (0, 1, 'S', 'S'),
                (1, 0, 'E', 'E'),
                (-1, 0, 'W', 'W')
            ]

            for dx, dy, wall_dir, out_dir in directions:
                if not current_cell.walls[wall_dir]:
                    nx, ny = current_cell.x + dx, current_cell.y + dy

                    if 0 <= nx < self.width and 0 <= ny < self.height:
                        if (nx, ny) not in visited:
                            visited.add((nx, ny))
                            queue.append(self.grid[ny][nx])
                            parent_map[(nx, ny)] = ((current_cell.x,
                                                     current_cell.y), out_dir)
        path = []
        curr = (exit_x, exit_y)

        while curr != (start_x, start_y):
            if curr not in parent_map:
                return []

            prev_coords, direction = parent_map[curr]
            path.append(direction)
            curr = prev_coords
        path.reverse()

        return path

    def _open_pacman_special_cells(self) -> None:
        center_x = self.width // 2
        center_y = self.height // 2

        special_cells = [
            (0, 0),
            (self.width - 1, 0),
            (0, self.height - 1),
            (self.width - 1, self.height - 1),
            (center_x, center_y)
        ]

        opposite_walls = {"N": "S", "S": "N", "E": "W", "W": "E"}

        for x, y in special_cells:
            if (x, y) in self._pattern_cells:
                continue

            cell = self.grid[y][x]
            closed_walls = [direction for direction, is_closed in
                            cell.walls.items() if is_closed]

            while len(closed_walls) >= 3:
                breakable_walls = []

                if "N" in closed_walls and y > 0:
                    breakable_walls.append("N")
                if "S" in closed_walls and y < self.height - 1:
                    breakable_walls.append("S")
                if "E" in closed_walls and x < self.width - 1:
                    breakable_walls.append("E")
                if "W" in closed_walls and x > 0:
                    breakable_walls.append("W")

                safe_walls = [w for w in breakable_walls if
                              self._is_safe_to_break(x, y, w)]

                if not safe_walls:
                    break
                wall_to_break = random.choice(safe_walls)
                cell.walls[wall_to_break] = False

                nx, ny = x, y
                if wall_to_break == "N":
                    ny -= 1
                elif wall_to_break == "S":
                    ny += 1
                elif wall_to_break == "E":
                    nx += 1
                elif wall_to_break == "W":
                    nx -= 1

                self.grid[ny][nx].walls[opposite_walls[wall_to_break]] = False
                closed_walls = [direction for direction, is_closed
                                in cell.walls.items()
                                if is_closed]
